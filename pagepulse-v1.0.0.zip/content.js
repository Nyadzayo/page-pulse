(function(){if(document.getElementById("pagepulse-overlay"))return;let n=null,l=null;l=document.createElement("div"),l.id="pagepulse-overlay",l.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    z-index: 2147483646; cursor: crosshair;
    background: rgba(0,0,0,0.04);
  `,document.body.appendChild(l);const s=document.createElement("div");s.style.cssText=`
    position: fixed; top: 16px; left: 50%; transform: translateX(-50%);
    z-index: 2147483647; padding: 9px 18px;
    background: #0F172A; color: #F1F5F9; border-radius: 8px;
    font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    display: flex; align-items: center; gap: 8px;
    letter-spacing: -0.01em;
  `,s.innerHTML=`
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
    </svg>
    Click an element to monitor
    <span style="font-family:monospace;font-size:10px;background:rgba(255,255,255,0.12);padding:2px 5px;border-radius:3px;color:#94A3B8;">ESC</span>
  `,document.body.appendChild(s);function c(o){l.style.pointerEvents="none";const t=document.elementFromPoint(o.clientX,o.clientY);l.style.pointerEvents="auto",!(!t||t===l||t===s)&&n!==t&&(u(),n=t,n.dataset.pagepulseOrigOutline=n.style.outline,n.dataset.pagepulseOrigBg=n.style.backgroundColor,n.style.outline="2px solid #10B981",n.style.backgroundColor="rgba(16,185,129,0.08)")}function u(){n&&(n.style.outline=n.dataset.pagepulseOrigOutline||"",n.style.backgroundColor=n.dataset.pagepulseOrigBg||"",delete n.dataset.pagepulseOrigOutline,delete n.dataset.pagepulseOrigBg,n=null)}function x(o){if(o.id)return`#${o.id}`;const t=o.getAttribute("data-testid");if(t)return`[data-testid="${t}"]`;const r=[];let e=o,i=0;for(;e&&e!==document.body&&i<5;){let a=e.tagName.toLowerCase();if(e.id&&i>0){r.unshift(`#${e.id}`);break}if(e.className&&typeof e.className=="string"){const f=e.className.trim().split(/\s+/).slice(0,2).map(y=>`.${y}`).join("");f&&(a+=f)}r.unshift(a),e=e.parentElement,i++}return r.join(" > ")||o.tagName.toLowerCase()}function h(o){const t=[];let r=o;for(;r&&r.nodeType===1;){let e=r.tagName.toLowerCase();if(e==="html"){t.unshift("/html");break}let i=1,a=r.previousElementSibling;for(;a;)a.tagName===r.tagName&&i++,a=a.previousElementSibling;t.unshift(`${e}[${i}]`),r=r.parentElement}return t.join("/")}function p(o){if(o.preventDefault(),o.stopPropagation(),!n)return;const t=n,e={url:window.location.href,selector:x(t),xpath:h(t),textFingerprint:t.textContent.trim().substring(0,100),baseline:t.textContent.trim(),label:`${t.tagName.toLowerCase()} on ${window.location.hostname}`};chrome.runtime.sendMessage({action:"createMonitor",data:e},i=>{var a;chrome.runtime.lastError,g(),i!=null&&i.success?d("Monitor added — checking every hour",(a=i.monitor)==null?void 0:a.id):(i==null?void 0:i.reason)==="limit_reached"?d("Monitor limit reached. Upgrade to Pro for more.",null,!0):d("Failed to create monitor. Please try again.",null,!0)})}function m(o){o.key==="Escape"&&g()}function d(o,t,r=!1){const e=document.createElement("div");e.style.cssText=`
      position: fixed; bottom: 24px; right: 24px; z-index: 2147483647;
      padding: 12px 18px; border-radius: 10px; max-width: 360px;
      font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      background: ${r?"#DC2626":"#059669"}; color: white;
      display: flex; align-items: center; gap: 8px;
      transition: opacity 0.3s ease;
      letter-spacing: -0.01em;
    `,r||(e.innerHTML='<span style="width:18px;height:18px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;flex-shrink:0;">&#10003;</span>');const i=document.createElement("span");if(i.textContent=o,e.appendChild(i),t){const a=document.createElement("a");a.href=chrome.runtime.getURL(`dashboard.html?monitor=${t}`),a.target="_blank",a.textContent="Edit",a.style.cssText="color:rgba(255,255,255,0.8);text-decoration:underline;text-underline-offset:2px;margin-left:4px;",e.appendChild(a)}document.body.appendChild(e),setTimeout(()=>{e.style.opacity="0",setTimeout(()=>e.remove(),300)},4e3)}function g(){u(),l==null||l.remove(),s==null||s.remove(),document.removeEventListener("mousemove",c,!0),document.removeEventListener("click",p,!0),document.removeEventListener("keydown",m,!0)}document.addEventListener("mousemove",c,!0),document.addEventListener("click",p,!0),document.addEventListener("keydown",m,!0)})();
