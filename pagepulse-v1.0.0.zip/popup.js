import"./chunks/modulepreload-polyfill-B5Qt9EMX.js";import{g as h,a as p,T as f,u as w}from"./chunks/storage-BHU-Fvfr.js";import{i as M,s as u,m as g,g as $,t as L}from"./chunks/theme-z8739pEs.js";document.addEventListener("DOMContentLoaded",async()=>{M();const o=document.getElementById("btn-theme");o.innerHTML=$()==="dark"?u:g,o.addEventListener("click",()=>{const t=L();o.innerHTML=t==="dark"?u:g}),chrome.action.setBadgeText({text:""});const s=await h(),r=await p(),i=f[r.tier],d=document.getElementById("monitor-list"),l=Object.values(s);if(l.length===0)d.innerHTML=`
      <div class="popup-empty">
        <div class="popup-empty-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <circle cx="12" cy="12" r="10"/><path d="M12 8v8m-4-4h8"/>
          </svg>
        </div>
        <h3>No monitors yet</h3>
        <p>Click below to select an element on a page and start tracking changes.</p>
      </div>
    `;else{d.innerHTML="";for(const t of l.sort((e,n)=>n.createdAt-e.createdAt)){const e=t.status==="ok"?"live":t.status==="broken"?"error":"warn",n=t.status==="broken"?'<span style="color:var(--red-text)">Broken · selector not found</span>':`${k(t.lastChecked)} <span class="sep">·</span> ${new URL(t.url).hostname}`,a=document.createElement("div");a.className="popup-monitor",a.innerHTML=`
        <div class="pm-status ${e}"></div>
        <div class="pm-info">
          <div class="pm-name" title="${v(t.label)}">${v(t.label)}</div>
          <div class="pm-meta">${n}</div>
        </div>
        <div class="pm-changes ${t.changeCount===0?"zero":""}">${t.changeCount||"0"}</div>
        <button class="pm-toggle ${t.active?"on":"off"}" data-id="${t.id}"></button>
      `,d.appendChild(a)}}d.addEventListener("click",async t=>{const e=t.target.closest(".pm-toggle");if(!e)return;const n=e.dataset.id,a=s[n];if(!a)return;const c=!a.active;await w(n,{active:c}),e.className=`pm-toggle ${c?"on":"off"}`,s[n].active=c}),document.getElementById("btn-add").addEventListener("click",async()=>{if(l.filter(c=>c.active).length>=i.maxMonitors)return;const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(e!=null&&e.id)||!e.url)return;const n=new URL(e.url).origin;await chrome.permissions.request({origins:[`${n}/*`]})&&(chrome.runtime.sendMessage({action:"startSelection",tabId:e.id},()=>void chrome.runtime.lastError),window.close())}),document.getElementById("btn-dashboard").addEventListener("click",t=>{t.preventDefault(),chrome.tabs.create({url:chrome.runtime.getURL("dashboard.html")}),window.close()});const m=l.filter(t=>t.active).length;document.getElementById("usage-text").innerHTML=`<strong>${m}</strong>/${i.maxMonitors} monitors`,document.getElementById("usage-fill").style.width=`${m/i.maxMonitors*100}%`});function k(o){if(!o)return"Not checked";const s=Date.now()-o,r=Math.floor(s/6e4);if(r<1)return"just now";if(r<60)return`${r}m ago`;const i=Math.floor(r/60);return i<24?`${i}h ago`:`${Math.floor(i/24)}d ago`}function v(o){const s=document.createElement("div");return s.textContent=o,s.innerHTML}
