import"./chunks/modulepreload-polyfill-B5Qt9EMX.js";import{g as L,a as M,T as y,u as b}from"./chunks/storage-BHU-Fvfr.js";import{i as T,s as v,m as f,g as k,t as E}from"./chunks/theme-z8739pEs.js";document.addEventListener("DOMContentLoaded",async()=>{T();const s=document.getElementById("btn-theme");s.innerHTML=k()==="dark"?v:f,s.addEventListener("click",()=>{const t=E();s.innerHTML=t==="dark"?v:f}),chrome.action.setBadgeText({text:""});const a=await L(),c=await M(),r=y[c.tier],d=document.getElementById("monitor-list"),l=Object.values(a);if(l.length===0)d.innerHTML=`
      <div class="popup-empty">
        <div class="popup-empty-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <circle cx="12" cy="12" r="10"/><path d="M12 8v8m-4-4h8"/>
          </svg>
        </div>
        <h3>No monitors yet</h3>
        <p>Click below to select an element on a page and start tracking changes.</p>
      </div>
    `;else{d.innerHTML="";for(const t of l.sort((e,n)=>n.createdAt-e.createdAt)){let e,n;t.active?t.status==="broken"?(e="error",n='<span style="color:var(--red-text)">Broken · selector not found</span>'):(e="live",n=`${w(t.lastChecked)} <span class="sep">·</span> ${new URL(t.url).hostname}`):(e="paused",n='<span style="color:var(--amber)">Paused</span>');const o=document.createElement("div");o.className="popup-monitor",o.dataset.id=t.id,o.innerHTML=`
        <div class="pm-status ${e}"></div>
        <div class="pm-info">
          <div class="pm-name" title="${$(t.label)}">${$(t.label)}</div>
          <div class="pm-meta">${n}</div>
        </div>
        <div class="pm-changes ${t.changeCount===0?"zero":""}">${t.changeCount||"0"}</div>
        <button class="pm-toggle ${t.active?"on":"off"}" data-id="${t.id}"></button>
      `,d.appendChild(o)}}d.addEventListener("click",async t=>{const e=t.target.closest(".pm-toggle");if(e){t.stopPropagation();const o=e.dataset.id,i=a[o];if(!i)return;const m=!i.active;await b(o,{active:m}),e.className=`pm-toggle ${m?"on":"off"}`,a[o].active=m;const p=e.closest(".popup-monitor"),g=p.querySelector(".pm-status"),h=p.querySelector(".pm-meta");m?(g.className=`pm-status ${i.status==="broken"?"error":"live"}`,h.innerHTML=`${w(i.lastChecked)} <span class="sep">·</span> ${new URL(i.url).hostname}`):(g.className="pm-status paused",h.innerHTML='<span style="color:var(--amber)">Paused</span>');return}const n=t.target.closest(".popup-monitor");n&&n.dataset.id&&(chrome.tabs.create({url:chrome.runtime.getURL(`dashboard.html?monitor=${n.dataset.id}`)}),window.close())}),document.getElementById("btn-add").addEventListener("click",async()=>{if(l.filter(i=>i.active).length>=r.maxMonitors)return;const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(e!=null&&e.id)||!e.url)return;const n=new URL(e.url).origin;await chrome.permissions.request({origins:[`${n}/*`]})&&(chrome.runtime.sendMessage({action:"startSelection",tabId:e.id},()=>void chrome.runtime.lastError),window.close())}),document.getElementById("btn-dashboard").addEventListener("click",t=>{t.preventDefault(),chrome.tabs.create({url:chrome.runtime.getURL("dashboard.html")}),window.close()});const u=l.filter(t=>t.active).length;document.getElementById("usage-text").innerHTML=`<strong>${u}</strong>/${r.maxMonitors} monitors`,document.getElementById("usage-fill").style.width=`${u/r.maxMonitors*100}%`});function w(s){if(!s)return"Not checked";const a=Date.now()-s,c=Math.floor(a/6e4);if(c<1)return"just now";if(c<60)return`${c}m ago`;const r=Math.floor(c/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}function $(s){const a=document.createElement("div");return a.textContent=s,a.innerHTML}
